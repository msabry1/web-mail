package com.foe.webmail;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WebmailApplicationTests {

	@Test
	void contextLoads() {
	}

}
