package com.foe.webmail.constants;

public abstract class MailStatus {
    public static final String INBOX = "inbox";
    public static final String TRASH = "trash";
}
