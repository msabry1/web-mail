package com.foe.webmail.constants;

public abstract class Importance {
    public static final String IMPORTANCE_LOW = "minor";
    public static final String IMPORTANCE_NORMAL = "medium";
    public static final String IMPORTANCE_HIGH = "major";
}
